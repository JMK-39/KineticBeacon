# KineticBeacon

KTCore companion module.

- Mod ID: `kineticbeacon`
- Required: `kineticcore` 26.8.17+
- Minecraft 1.20.1 / Forge 47.x / Java 17

全局信标配置可从 KT 模块菜单打开，并保存在 `config/kineticcore/beacon.toml`。配置由服务端持有；未实现远程保存协议前，连接专用服务器时菜单会禁用该页，避免误改客户端副本。
