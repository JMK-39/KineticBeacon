package dev.xyat.kineticbeacon;

import com.mojang.logging.LogUtils;
import dev.xyat.kineticbeacon.beacon.config.BeaconConfig;
import dev.xyat.kineticbeacon.beacon.config.BeaconConfigGui;
import dev.xyat.kineticbeacon.beacon.network.BeaconNetwork;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(KineticBeacon.MODID)
public final class KineticBeacon {
    public static final String MODID = "kineticbeacon";
    public static final Logger LOGGER = LogUtils.getLogger();

    public KineticBeacon(FMLJavaModLoadingContext context) {
        BeaconConfig.load();
        BeaconNetwork.register();
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> BeaconConfigGui::load);
    }
}
